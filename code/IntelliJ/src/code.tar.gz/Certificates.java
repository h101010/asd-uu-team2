
import java.util.*;

public class Certificates {

    public Certificates() {
    }


}