
import java.util.*;


public class SubscriptionModel {
    private Date dueDate;

    public SubscriptionModel() {
    }

    public float calculateAmount(List<Match> listOfMatches) {
    	return 0;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
}