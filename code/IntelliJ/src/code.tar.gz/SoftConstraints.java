
import java.util.*;


public class SoftConstraints {

    private Date preferredTime;

    public SoftConstraints() {
    }

    public void setPreferredTime(Date preferredTime) {
    	this.preferredTime = preferredTime;
    }
    
    public Date getPreferredTime() {
    	return this.preferredTime;
    }
}