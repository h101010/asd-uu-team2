
import java.util.*;

public class HardConstraints {

    private Date deadline;

    private List<Skills> skillsList;


    public HardConstraints() {

    }


    public void addSkills(String Description) {

    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public List<Skills> getSkillsList() {
        return skillsList;
    }
}