
import java.util.*;

/**
 * 
 */
public class PersonalDetails {

    private String Email;

    private String Telephone;

    private String Name;


    public PersonalDetails() {
    }


    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getTelephone() {
        return Telephone;
    }

    public void setTelephone(String telephone) {
        Telephone = telephone;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}