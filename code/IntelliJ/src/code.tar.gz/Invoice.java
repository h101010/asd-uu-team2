import java.util.*;

/**
 * Invoice interface
 */
public interface Invoice {

    void pay();

}