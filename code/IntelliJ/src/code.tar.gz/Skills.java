
import java.util.*;

public interface Skills {

	boolean validate();
	
}