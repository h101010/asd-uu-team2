
import java.util.*;

public class UserManagement {
    private static final UserManagement userManagement = new UserManagement();

    public UserManagement() {
    }

    public void createAccount() {
    }

    public void resetPassword(User user) {
    }

    public void deleteAccount(User user) {
    }

    public static UserManagement getUserManagement() {
        return userManagement;
    }

}